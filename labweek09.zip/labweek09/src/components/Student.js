function Student(props) {
  return (
    <div>
      <h5>{props.sid}</h5>
      <h5>{props.sname}</h5>
    </div>
  );
}

export default Student;
