function College() {
  return <h6>Geoerge Brown College, Toronto</h6>;
}

export default College;
