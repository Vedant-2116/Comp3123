function Welcome(props) {
  return (
    <div>
      <h1>Welcome to FullStack Devlopment - 1</h1>
      <h3>React JS Programming Week09 Lab Exercise</h3>
    </div>
  );
}

export default Welcome;
