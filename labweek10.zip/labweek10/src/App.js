
import './App.css';
import DataForm from './DataForm';

function App() {
  return (
    <div>
       <DataForm />
    </div>
  );
}

export default App;
